/* =========================================================
   TRANSACTION HELPERS
   ========================================================= */

/**
 * Membuat database baru yang aman.
 */
function cloneDatabase(database: Database): Database {
  return ensureDatabaseDefaults(
    JSON.parse(JSON.stringify(database))
  );
}

/**
 * Membuat ID transaksi.
 */
function createTransactionId(prefix: string): string {
  return generateUniqueId(prefix);
}

/* =========================================================
   BROADCAST
========================================================= */

export function updateBroadcastMessageTransaction(
  db: Database,
  message: string
): Database {
  const next = cloneDatabase(db);

  next.broadcastMessage =
    String(message || "").trim();

  next.lastUpdated =
    new Date().toISOString();

  return next;
}

/* =========================================================
   SESSION / RIWAYAT PERTEMUAN
========================================================= */

export function checkDuplicateSession(
  db: Database,
  tanggal: string,
  tutorId: string,
  siswaId: string
): boolean {
  return db.sessions.some(session =>
    session.tanggal === tanggal &&
    session.tutorId === tutorId &&
    session.siswaId === siswaId
  );
}

export function addSessionTransaction(
  db: Database,
  session: RiwayatPertemuan
): Database {
  const next = cloneDatabase(db);

  const duplicate =
    checkDuplicateSession(
      next,
      session.tanggal,
      session.tutorId,
      session.siswaId
    );

  if (duplicate) {
    throw new Error(
      "Sesi untuk tutor, siswa, dan tanggal tersebut sudah ada."
    );
  }

  const newSession: RiwayatPertemuan = {
    ...session,
    id:
      session.id ||
      createTransactionId("SES")
  };

  next.sessions.push(newSession);

  next.lastUpdated =
    new Date().toISOString();

  return recalculateAllLedgers(next);
}

export function deleteSessionTransaction(
  db: Database,
  sessionId: string
): Database {
  const next = cloneDatabase(db);

  next.sessions =
    next.sessions.filter(
      session =>
        session.id !== sessionId
    );

  next.lastUpdated =
    new Date().toISOString();

  return recalculateAllLedgers(next);
}

/* =========================================================
   PEMBAYARAN SISWA
========================================================= */

export function addPaymentTransaction(
  db: Database,
  payment: PembayaranSiswa
): Database {
  const next = cloneDatabase(db);

  const newPayment: PembayaranSiswa = {
    ...payment,
    id:
      payment.id ||
      createTransactionId("PAY"),
    jumlah:
      Number(payment.jumlah) || 0,
    statusTitipan:
      payment.statusTitipan ||
      (
        payment.metode === "tutor"
          ? "pending"
          : "diterima"
      )
  };

  next.payments.push(newPayment);

  /*
   * Pembayaran siswa masuk ke rekening siswa.
   *
   * Debit = uang masuk ke saldo siswa.
   */
  const existingLedger =
    next.studentLedger.some(
      tx =>
        tx.referensiId === newPayment.id
    );

  if (!existingLedger) {
    next.studentLedger.push({
      id: createTransactionId("SLD"),
      tanggal: newPayment.tanggal,
      siswaId: newPayment.siswaId,
      tipe: "debit",
      keterangan:
        `Pembayaran siswa - ${newPayment.siswaNama}`,
      jumlah:
        Number(newPayment.jumlah) || 0,
      saldoBerjalan: 0,
      referensiId: newPayment.id
    });
  }

  next.lastUpdated =
    new Date().toISOString();

  return recalculateAllLedgers(next);
}

/* =========================================================
   TITIPAN TUTOR
========================================================= */

export function confirmTutorDepositHandover(
  db: Database,
  paymentId: string
): Database {
  const next = cloneDatabase(db);

  const payment =
    next.payments.find(
      p => p.id === paymentId
    );

  if (!payment) {
    throw new Error(
      "Data pembayaran tidak ditemukan."
    );
  }

  payment.statusTitipan = "diterima";
  payment.tanggalSerah =
    getTodayDateString();

  /*
   * Jika titipan tutor sudah diserahkan,
   * uang masuk ke kas lembaga.
   */
  const kasReference =
    `TITIPAN-${payment.id}`;

  const alreadyKas =
    next.kas.some(
      kas =>
        kas.id === kasReference
    );

  if (!alreadyKas) {
    next.kas.push({
      id: kasReference,
      tanggal:
        payment.tanggalSerah,
      tipe: "masuk",
      keterangan:
        `Serah terima titipan tutor - ${payment.tutorNama || payment.tutorId || ""} - ${payment.siswaNama}`,
      jumlah:
        Number(payment.jumlah) || 0,
      saldoBerjalan: 0
    });
  }

  next.lastUpdated =
    new Date().toISOString();

  return recalculateAllLedgers(next);
}

export function undoTutorDepositHandover(
  db: Database,
  paymentId: string
): Database {
  const next = cloneDatabase(db);

  const payment =
    next.payments.find(
      p => p.id === paymentId
    );

  if (!payment) {
    throw new Error(
      "Data pembayaran tidak ditemukan."
    );
  }

  payment.statusTitipan = "pending";
  payment.tanggalSerah =
    undefined;

  const kasReference =
    `TITIPAN-${payment.id}`;

  next.kas =
    next.kas.filter(
      kas =>
        kas.id !== kasReference
    );

  next.lastUpdated =
    new Date().toISOString();

  return recalculateAllLedgers(next);
}

/* =========================================================
   HONOR TUTOR
========================================================= */

export function payTutorHonorTransaction(
  db: Database,
  tutorId: string,
  jumlah: number,
  keterangan: string = "Pembayaran honor tutor",
  tanggal: string = getTodayDateString()
): Database {
  const next = cloneDatabase(db);

  const amount =
    Number(jumlah) || 0;

  if (amount <= 0) {
    throw new Error(
      "Nominal honor harus lebih dari 0."
    );
  }

  next.tutorLedger.push({
    id: createTransactionId("THR"),
    tanggal,
    tutorId,
    tipe: "debit",
    keterangan,
    jumlah: amount,
    saldoBerjalan: 0
  });

  next.kas.push({
    id: createTransactionId("KAS"),
    tanggal,
    tipe: "keluar",
    keterangan:
      `Pembayaran honor tutor: ${keterangan}`,
    jumlah: amount,
    saldoBerjalan: 0
  });

  next.lastUpdated =
    new Date().toISOString();

  return recalculateAllLedgers(next);
}

/* =========================================================
   PENGELUARAN UMUM
========================================================= */

export function addGeneralExpenseTransaction(
  db: Database,
  jumlah: number,
  keterangan: string,
  tanggal: string = getTodayDateString()
): Database {
  const next = cloneDatabase(db);

  const amount =
    Number(jumlah) || 0;

  if (amount <= 0) {
    throw new Error(
      "Nominal pengeluaran harus lebih dari 0."
    );
  }

  next.kas.push({
    id: createTransactionId("KAS"),
    tanggal,
    tipe: "keluar",
    keterangan,
    jumlah: amount,
    saldoBerjalan: 0
  });

  next.lastUpdated =
    new Date().toISOString();

  return recalculateAllLedgers(next);
}

/* =========================================================
   PEMASUKAN LAIN
========================================================= */

export function addOtherIncomeTransaction(
  db: Database,
  income: PemasukanLain
): Database {
  const next = cloneDatabase(db);

  const newIncome: PemasukanLain = {
    ...income,
    jumlah:
      Number(income.jumlah) || 0
  };

  if (!newIncome.id) {
    newIncome.id =
      createTransactionId("OIN");
  }

  next.otherIncomes.push(
    newIncome
  );

  next.kas.push({
    id: createTransactionId("KAS"),
    tanggal:
      newIncome.tanggal ||
      getTodayDateString(),
    tipe: "masuk",
    keterangan:
      newIncome.keterangan ||
      newIncome.sumber ||
      "Pemasukan lain",
    jumlah:
      Number(newIncome.jumlah) || 0,
    saldoBerjalan: 0
  });

  next.lastUpdated =
    new Date().toISOString();

  return recalculateAllLedgers(next);
}

/* =========================================================
   LAPORAN KEHADIRAN
========================================================= */

export function submitAttendanceReport(
  db: Database,
  report: LaporanKehadiran
): Database {
  const next = cloneDatabase(db);

  const newReport: LaporanKehadiran = {
    ...report,

    id:
      report.id ||
      createTransactionId("ATT"),

    status:
      report.status ||
      "pending",

    tanggalProses:
      report.tanggalProses
  };

  /*
   * Jangan membuat laporan ganda.
   */
  const duplicate =
    next.attendanceReports.some(
      item =>
        item.tutorId ===
          newReport.tutorId &&
        item.siswaId ===
          newReport.siswaId &&
        item.tanggal ===
          newReport.tanggal
    );

  if (duplicate) {
    throw new Error(
      "Laporan kehadiran untuk tutor, siswa, dan tanggal tersebut sudah ada."
    );
  }

  next.attendanceReports.push(
    newReport
  );

  next.lastUpdated =
    new Date().toISOString();

  return next;
}

export function verifyAttendanceReport(
  db: Database,
  reportId: string,
  catatanAdmin: string = ""
): Database {
  const next = cloneDatabase(db);

  const report =
    next.attendanceReports.find(
      item =>
        item.id === reportId
    );

  if (!report) {
    throw new Error(
      "Laporan kehadiran tidak ditemukan."
    );
  }

  report.status = "disetujui";
  report.catatanAdmin =
    catatanAdmin;
  report.tanggalProses =
    getTodayDateString();

  /*
   * Setelah laporan disetujui,
   * tambahkan honor tutor jika belum dibuat.
   */
  const alreadyCreated =
    next.tutorLedger.some(
      tx =>
        tx.referensiId ===
        `ATT-${report.id}`
    );

  if (!alreadyCreated) {
    const program =
      next.programs.find(
        p =>
          p.id ===
          report.programId
      );

    const honor =
      Number(
        program?.honorTutor || 0
      );

    if (honor > 0) {
      next.tutorLedger.push({
        id:
          createTransactionId("THR"),
        tanggal:
          report.tanggal,
        tutorId:
          report.tutorId,
        tipe: "kredit",
        keterangan:
          `Honor sesi ${report.siswaNama}`,
        jumlah: honor,
        saldoBerjalan: 0,
        referensiId:
          `ATT-${report.id}`
      });
    }
  }

  next.lastUpdated =
    new Date().toISOString();

  return recalculateAllLedgers(next);
}

export function undoVerifyAttendanceReport(
  db: Database,
  reportId: string
): Database {
  const next = cloneDatabase(db);

  const report =
    next.attendanceReports.find(
      item =>
        item.id === reportId
    );

  if (!report) {
    throw new Error(
      "Laporan kehadiran tidak ditemukan."
    );
  }

  report.status = "pending";
  report.tanggalProses =
    undefined;

  next.tutorLedger =
    next.tutorLedger.filter(
      tx =>
        tx.referensiId !==
        `ATT-${report.id}`
    );

  next.lastUpdated =
    new Date().toISOString();

  return recalculateAllLedgers(next);
}

export function deleteAttendanceReport(
  db: Database,
  reportId: string
): Database {
  const next = cloneDatabase(db);

  next.attendanceReports =
    next.attendanceReports.filter(
      report =>
        report.id !== reportId
    );

  /*
   * Jika laporan dihapus,
   * honor yang berasal dari laporan tersebut
   * juga dihapus.
   */
  next.tutorLedger =
    next.tutorLedger.filter(
      tx =>
        tx.referensiId !==
        `ATT-${reportId}`
    );

  next.lastUpdated =
    new Date().toISOString();

  return recalculateAllLedgers(next);
}

/* =========================================================
   EXPORT DEFAULT
========================================================= */

export default {
  getDatabase,
  saveDatabase,
  updateDatabase,

  getLocalDatabase,
  saveLocalDatabase,

  ensureDatabaseDefaults,
  generateCleanDatabase,

  recalculateAllLedgers,

  getStudentBalance,
  getTutorHonorBalance,
  getTutorDepositBalance,
  getKasLembagaBalance,

  filterByDateRange,

  generateUniqueId,

  deleteRecordFromSupabase,
  deleteFromDatabase,

  updateBroadcastMessageTransaction,

  checkDuplicateSession,
  addSessionTransaction,
  deleteSessionTransaction,

  addPaymentTransaction,

  confirmTutorDepositHandover,
  undoTutorDepositHandover,

  payTutorHonorTransaction,

  addGeneralExpenseTransaction,
  addOtherIncomeTransaction,

  submitAttendanceReport,
  verifyAttendanceReport,
  undoVerifyAttendanceReport,
  deleteAttendanceReport
};