import { createClient } from "@supabase/supabase-js";
import type { Database } from "./db";

/**
 * =========================================================
 * SUPABASE CONFIGURATION
 * =========================================================
 */

const metaEnv = (import.meta as any)?.env || {};

export const SUPABASE_URL = String(
  metaEnv.VITE_SUPABASE_URL ||
    "https://pxtudqcutpjvdnqbhwgf.supabase.co"
)
  .replace(/\/rest\/v1\/?$/, "")
  .replace(/\/$/, "");

export const SUPABASE_ANON_KEY = String(
  metaEnv.VITE_SUPABASE_ANON_KEY ||
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB4dHVkcWN1dHBqdmRucWJod2dmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI4MDExMTMsImV4cCI6MjA5ODM3NzExM30.65l1hniJcmumYk3qvZZQ73d767mAE8_kvz9xZKv2COE"
);

if (!SUPABASE_URL) {
  console.error("[Supabase] URL tidak tersedia.");
}

if (!SUPABASE_ANON_KEY) {
  console.error("[Supabase] Anon key tidak tersedia.");
}

/**
 * =========================================================
 * SUPABASE CLIENT
 * =========================================================
 */

export const supabase = createClient(
  SUPABASE_URL,
  SUPABASE_ANON_KEY,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true
    },
    realtime: {
      params: {
        eventsPerSecond: 10
      }
    }
  }
);

/**
 * =========================================================
 * SYNC STATE
 * =========================================================
 */

export interface SyncState {
  status: "idle" | "syncing" | "success" | "error";
  lastSynced: string | null;
  errorMessage: string | null;
}

let syncState: SyncState = {
  status: "idle",
  lastSynced: null,
  errorMessage: null
};

const syncListeners = new Set<(state: SyncState) => void>();

function setSyncState(next: Partial<SyncState>) {
  syncState = {
    ...syncState,
    ...next
  };

  syncListeners.forEach(listener => {
    try {
      listener({ ...syncState });
    } catch (error) {
      console.error("[Supabase] Sync listener error:", error);
    }
  });
}

/**
 * Dipakai AdminDashboard untuk memantau status sinkronisasi.
 */
export function subscribeToSyncState(
  listener: (state: SyncState) => void
): () => void {
  syncListeners.add(listener);

  // Kirim state terbaru langsung
  listener({ ...syncState });

  return () => {
    syncListeners.delete(listener);
  };
}

/**
 * =========================================================
 * SUPABASE TABLE
 * =========================================================
 *
 * Tabel utama yang digunakan aplikasi:
 *
 * public.rumah_belajar_db
 *
 * Struktur:
 * id         TEXT PRIMARY KEY
 * data       JSONB
 * updated_at TIMESTAMPTZ
 */

const TABLE_NAME = "rumah_belajar_db";
const DATABASE_ID = "main_v1";

/**
 * =========================================================
 * SQL SCHEMA
 * =========================================================
 */

export const SUPABASE_SQL_SCHEMA = `
CREATE TABLE IF NOT EXISTS public.rumah_belajar_db (
    id TEXT PRIMARY KEY,
    data JSONB NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.rumah_belajar_db ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "rumah_belajar_public_select"
ON public.rumah_belajar_db;

DROP POLICY IF EXISTS "rumah_belajar_public_insert"
ON public.rumah_belajar_db;

DROP POLICY IF EXISTS "rumah_belajar_public_update"
ON public.rumah_belajar_db;

DROP POLICY IF EXISTS "rumah_belajar_public_delete"
ON public.rumah_belajar_db;

CREATE POLICY "rumah_belajar_public_select"
ON public.rumah_belajar_db
FOR SELECT
TO anon, authenticated
USING (true);

CREATE POLICY "rumah_belajar_public_insert"
ON public.rumah_belajar_db
FOR INSERT
TO anon, authenticated
WITH CHECK (true);

CREATE POLICY "rumah_belajar_public_update"
ON public.rumah_belajar_db
FOR UPDATE
TO anon, authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "rumah_belajar_public_delete"
ON public.rumah_belajar_db
FOR DELETE
TO anon, authenticated
USING (true);

ALTER TABLE public.rumah_belajar_db REPLICA IDENTITY FULL;
`;

/**
 * =========================================================
 * PUSH LOCAL -> SUPABASE
 * =========================================================
 */

export async function pushToSupabase(
  db: Database,
  force = false
): Promise<boolean> {
  try {
    setSyncState({
      status: "syncing",
      errorMessage: null
    });

    const payload = {
      id: DATABASE_ID,
      data: db,
      updated_at: new Date().toISOString()
    };

    const { error } = await supabase
      .from(TABLE_NAME)
      .upsert(payload, {
        onConflict: "id"
      });

    if (error) {
      console.error("[Supabase] Push gagal:", error);

      setSyncState({
        status: "error",
        errorMessage: error.message
      });

      return false;
    }

    const syncedAt = new Date().toISOString();

    try {
      localStorage.setItem(
        "supabase_last_synced",
        syncedAt
      );
    } catch {}

    setSyncState({
      status: "success",
      lastSynced: syncedAt,
      errorMessage: null
    });

    return true;
  } catch (error: any) {
    console.error("[Supabase] Push exception:", error);

    setSyncState({
      status: "error",
      errorMessage:
        error?.message ||
        "Gagal mengunggah database ke Supabase."
    });

    return false;
  }
}

/**
 * =========================================================
 * PULL SUPABASE -> LOCAL
 * =========================================================
 */

export async function pullFromSupabase(): Promise<Database | null> {
  try {
    setSyncState({
      status: "syncing",
      errorMessage: null
    });

    const { data, error } = await supabase
      .from(TABLE_NAME)
      .select("data, updated_at")
      .eq("id", DATABASE_ID)
      .maybeSingle();

    if (error) {
      console.error("[Supabase] Pull gagal:", error);

      setSyncState({
        status: "error",
        errorMessage: error.message
      });

      return null;
    }

    if (!data?.data) {
      setSyncState({
        status: "idle",
        errorMessage: null
      });

      return null;
    }

    const cloudDb = data.data as Database;

    const syncedAt =
      data.updated_at ||
      new Date().toISOString();

    try {
      localStorage.setItem(
        "supabase_last_synced",
        syncedAt
      );
    } catch {}

    setSyncState({
      status: "success",
      lastSynced: syncedAt,
      errorMessage: null
    });

    return cloudDb;
  } catch (error: any) {
    console.error("[Supabase] Pull exception:", error);

    setSyncState({
      status: "error",
      errorMessage:
        error?.message ||
        "Gagal mengambil database dari Supabase."
    });

    return null;
  }
}

/**
 * =========================================================
 * REALTIME DATABASE SYNC
 * =========================================================
 */

let realtimeChannel:
  ReturnType<typeof supabase.channel> | null = null;

/**
 * Memulai listener perubahan database Supabase.
 *
 * Callback dipanggil ketika data berubah di cloud.
 */
export function subscribeToDatabaseChanges(
  callback: (db: Database) => void
): () => void {
  if (realtimeChannel) {
    try {
      supabase.removeChannel(realtimeChannel);
    } catch {}

    realtimeChannel = null;
  }

  realtimeChannel = supabase
    .channel("rumah-belajar-db-realtime")
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: TABLE_NAME,
        filter: `id=eq.${DATABASE_ID}`
      },
      payload => {
        try {
          const record = payload.new as {
            data?: Database;
            updated_at?: string;
          };

          if (record?.data) {
            const syncedAt =
              record.updated_at ||
              new Date().toISOString();

            try {
              localStorage.setItem(
                "supabase_last_synced",
                syncedAt
              );
            } catch {}

            setSyncState({
              status: "success",
              lastSynced: syncedAt,
              errorMessage: null
            });

            callback(record.data);
          }
        } catch (error) {
          console.error(
            "[Supabase] Realtime processing error:",
            error
          );
        }
      }
    )
    .subscribe(status => {
      if (status === "SUBSCRIBED") {
        console.log(
          "[Supabase] Realtime connected."
        );
      }

      if (
        status === "CHANNEL_ERROR" ||
        status === "TIMED_OUT" ||
        status === "CLOSED"
      ) {
        console.warn(
          "[Supabase] Realtime status:",
          status
        );
      }
    });

  return () => {
    if (realtimeChannel) {
      try {
        supabase.removeChannel(
          realtimeChannel
        );
      } catch {}

      realtimeChannel = null;
    }
  };
}

/**
 * Alias supaya kompatibel dengan kode lama.
 */
export const subscribeToSupabase =
  subscribeToDatabaseChanges;